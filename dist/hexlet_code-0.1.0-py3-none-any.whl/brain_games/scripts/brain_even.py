#!usr/bin/env python
from brain_games import three_num


def main():
    print('Welcome to the Brain Games!')
    three_num.choice()

    if __name__ == '__main__':
        main()
